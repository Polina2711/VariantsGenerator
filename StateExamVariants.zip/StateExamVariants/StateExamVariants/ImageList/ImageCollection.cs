﻿namespace ImageList
{
    public class ImageCollection
    {
    }
}