﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace StateExamVariants
{
    class Data
    {
        public List<string> Task { get; set; }
        public ImageList.ImageCollection Images { get; }
    }
   
}
