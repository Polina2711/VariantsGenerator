﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace StateExamVariants
{
    public class Repository
    {
        public void Generator(int tasknum, int numboftasks)
        {
            ParserFromMathege parser = new ParserFromMathege();
            while (numboftasks != 0)
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                Stream stream = assembly.GetManifestResourceStream("StateExamVariants.AL.Task"+tasknum+".txt");
                StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                List<string> tasknumbers = new List<string>();
                string taskn;
                while ((taskn = reader.ReadLine()) != null)
                {
                    tasknumbers.Add(taskn);
                }
                reader.Close();

                Random r = new Random();

                string [] result=parser.GetTask(r.Next(tasknumbers.Count));

                numboftasks--;
            }
        }
    }
}
